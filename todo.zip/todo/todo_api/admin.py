from django.contrib import admin
from todo_api.models import Todo
# Register your models here.
admin.site.register(Todo)